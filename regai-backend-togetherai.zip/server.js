
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const axios = require("axios");

const app = express();
app.use(cors());
app.use(express.json());

const TOGETHER_API_KEY = process.env.TOGETHER_API_KEY;
const TOGETHER_API_URL = "https://api.together.xyz/v1/chat/completions";

app.post("/ask", async (req, res) => {
  const { question } = req.body;

  try {
    const response = await axios.post(
      TOGETHER_API_URL,
      {
        model: "mistralai/Mistral-7B-Instruct-v0.2",
        messages: [{ role: "user", content: question }],
      },
      {
        headers: {
          "Authorization": `Bearer ${TOGETHER_API_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    const answer = response.data.choices?.[0]?.message?.content?.trim() || "No answer received.";
    res.json({ answer });
  } catch (error) {
    console.error("Together API Error:", error.response?.data || error.message);
    res.status(500).json({ error: "Failed to get response from Together.ai." });
  }
});

app.listen(3000, () => {
  console.log("✅ RegAI backend using Together.ai running on port 3000");
});
